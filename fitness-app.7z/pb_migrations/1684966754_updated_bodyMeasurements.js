migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("ounpei02blyv711")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "zeos0mce",
    "name": "bodyFat",
    "type": "number",
    "required": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null
    }
  }))

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "8guzsc6i",
    "name": "user",
    "type": "relation",
    "required": true,
    "unique": false,
    "options": {
      "collectionId": "_pb_users_auth_",
      "cascadeDelete": false,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": []
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("ounpei02blyv711")

  // remove
  collection.schema.removeField("zeos0mce")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "8guzsc6i",
    "name": "user",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "collectionId": "_pb_users_auth_",
      "cascadeDelete": false,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": []
    }
  }))

  return dao.saveCollection(collection)
})
