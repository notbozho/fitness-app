migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("6ilgps97xsukiqm")

  collection.listRule = ""
  collection.viewRule = ""

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("6ilgps97xsukiqm")

  collection.listRule = null
  collection.viewRule = null

  return dao.saveCollection(collection)
})
