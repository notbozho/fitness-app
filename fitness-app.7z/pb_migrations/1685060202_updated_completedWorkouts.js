migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("a37l64l6twf5kt7")

  // remove
  collection.schema.removeField("ysokhyqp")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "bkt31p11",
    "name": "workout",
    "type": "text",
    "required": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "hu28fozx",
    "name": "date",
    "type": "date",
    "required": true,
    "unique": false,
    "options": {
      "min": "",
      "max": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("a37l64l6twf5kt7")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "ysokhyqp",
    "name": "workout",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "collectionId": "5jkv1xkxhq0znhp",
      "cascadeDelete": false,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": []
    }
  }))

  // remove
  collection.schema.removeField("bkt31p11")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "hu28fozx",
    "name": "date",
    "type": "date",
    "required": false,
    "unique": false,
    "options": {
      "min": "",
      "max": ""
    }
  }))

  return dao.saveCollection(collection)
})
