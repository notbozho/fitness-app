migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("6ilgps97xsukiqm")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "u0nafzrw",
    "name": "description",
    "type": "text",
    "required": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("6ilgps97xsukiqm")

  // remove
  collection.schema.removeField("u0nafzrw")

  return dao.saveCollection(collection)
})
