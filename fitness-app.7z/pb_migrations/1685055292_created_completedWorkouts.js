migrate((db) => {
  const collection = new Collection({
    "id": "a37l64l6twf5kt7",
    "created": "2023-05-25 22:54:52.807Z",
    "updated": "2023-05-25 22:54:52.807Z",
    "name": "completedWorkouts",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "hu28fozx",
        "name": "date",
        "type": "date",
        "required": false,
        "unique": false,
        "options": {
          "min": "",
          "max": ""
        }
      },
      {
        "system": false,
        "id": "ysokhyqp",
        "name": "workout",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "collectionId": "5jkv1xkxhq0znhp",
          "cascadeDelete": false,
          "minSelect": null,
          "maxSelect": 1,
          "displayFields": []
        }
      },
      {
        "system": false,
        "id": "2yme0p4g",
        "name": "user",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "collectionId": "_pb_users_auth_",
          "cascadeDelete": false,
          "minSelect": null,
          "maxSelect": 1,
          "displayFields": []
        }
      }
    ],
    "indexes": [],
    "listRule": "",
    "viewRule": "",
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("a37l64l6twf5kt7");

  return dao.deleteCollection(collection);
})
